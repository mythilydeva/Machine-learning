# Movie Trailer Website
This is a python project to open a website for movies and  trailers the listed movies.


__This is web-based Software.__  It can be accessed using a web browser.

Python 2.7 Interpreter is required to execute the Python files

## Installation
To install the __Movie Trailer Website__ files, just download the zip file.
For instructions on installing Python 2.7 Interpreter, 
please check out the [installation manual]("https://docs.python.org/2/install/index.html")

### Building the web page in TERMINAL
In the Start menu, select "Run...", and type in cmd. This will cause the Windows terminal to open.
Type cd \movie_website_creation_project(directory name) to change directory to your program folder, and hit Enter.
Type entertainer.py to run your program!

### Generating the page in IDLE
Right Click on entertainer.py file and choose edit with IDLE
In the "entertainer.py" window, select Run, Run Module (or press F5) to run your script.
The "Python Shell" window will display the output of your script.
This will take you to the website.


NOTE: The entertainer.py class contains the movie details which will be send to the fresh_tomatoes.py,
by using "fresh_tomatoes.open_movies_page(list_of_movies)" statement.
The media file assigns the movie names using "Movie" class.
